#ifndef SECRETS_H
#define SECRETS_H

const char* ssid = "yourSSID";
const char* password = "yourPASSWORD";

#endif // SECRETS_H